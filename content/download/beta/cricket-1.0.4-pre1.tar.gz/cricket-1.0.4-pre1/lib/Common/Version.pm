$Common::global::gVersion = "Cricket version 1.0.4-pre1 (2002-04-16)";

$Common::global::gVersion =~ s/[!]!VERSION![!]/devel/;
1;
